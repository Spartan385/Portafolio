document.addEventListener('DOMContentLoaded', () => {
    const audio = document.getElementById('music');
    const boton = document.getElementById('botonPlay');

    // Recupera estado si la música debe sonar
    const musicaActiva = localStorage.getItem('musicaActiva') === 'true';

    if (musicaActiva && audio) {
        audio.play().catch(() => {
            console.log('Autoplay bloqueado por navegador');
        });
    }

    // Solo en index.html está el botón, si existe botón, asignamos evento
    if (boton && audio) {
        boton.textContent = audio.paused ? 'Play' : 'Pausa';

        boton.addEventListener('click', () => {
            if (audio.paused) {
                audio.play();
                boton.textContent = 'Pausa';
                localStorage.setItem('musicaActiva', 'true');
            } else {
                audio.pause();
                boton.textContent = 'Play';
                localStorage.setItem('musicaActiva', 'false');
            }
        });

        // Sincronizar botón con cambios de estado
        audio.addEventListener('play', () => {
            boton.textContent = 'Pausa';
            localStorage.setItem('musicaActiva', 'true');
        });
        audio.addEventListener('pause', () => {
            boton.textContent = 'Play';
            localStorage.setItem('musicaActiva', 'false');
        });
    }
});