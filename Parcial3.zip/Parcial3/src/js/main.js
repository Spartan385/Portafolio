import * as THREE from 'three';
import { OBJLoader } from 'three/examples/jsm/loaders/OBJLoader.js';
import { MTLLoader } from 'three/examples/jsm/loaders/MTLLoader.js';

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
    75, window.innerWidth / window.innerHeight, 0.1, 1000
);

camera.position.set(-50, 10, 35);
camera.rotateY(-1)
    /* camera.position.set(0, 10, 25); */

scene.background = new THREE.Color(0x00C9FC);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
directionalLight.position.set(1, 1, 1);
scene.add(directionalLight);

const ambientLight = new THREE.AmbientLight(0x404040);
scene.add(ambientLight);

//Mapa
let mapa;

const mtlLoader = new MTLLoader();
mtlLoader.load('./src/modelos/mapa.mtl', (materials) => {
    materials.preload();

    const objLoader = new OBJLoader();
    objLoader.setMaterials(materials);

    objLoader.load('./src/modelos/mapa.obj',
        (object) => {
            console.log('Modelo cargado:', object);
            mapa = object;
            mapa.position.set(0, -3, 0);
            mapa.scale.set(10, 3, 10);
            scene.add(mapa);
        },
        undefined,
        (error) => {
            console.error('Error al cargar el modelo:', error);
        }
    );
});

//Personaje
let personaje;

const mtlLoader1 = new MTLLoader();
mtlLoader1.load('./src/modelos/masterchief.mtl', (materials) => {
    materials.preload();

    const objLoader = new OBJLoader();
    objLoader.setMaterials(materials);

    objLoader.load('./src/modelos/masterchief.obj',
        (object) => {
            console.log('Modelo cargado:', object);
            personaje = object;
            personaje.position.set(-30, 0, 20);
            personaje.scale.set(1, 1, 1);
            personaje.rotateY(8.5);
            scene.add(personaje);
        },
        undefined,
        (error) => {
            console.error('Error al cargar el modelo:', error);
        }
    );
});

//Carro
let carro;

const mtlLoader2 = new MTLLoader();
mtlLoader2.load('./src/modelos/carro.mtl', (materials) => {
    materials.preload();

    const objLoader = new OBJLoader();
    objLoader.setMaterials(materials);

    objLoader.load('./src/modelos/carro.obj',
        (object) => {
            console.log('Modelo cargado:', object);
            carro = object;
            carro.position.set(-10, 0, -5);
            carro.scale.set(2, 2, 2);

            scene.add(carro);
        },
        undefined,
        (error) => {
            console.error('Error al cargar el modelo:', error);
        }
    );
});

//Arma
let arma;

const mtlLoader3 = new MTLLoader();
mtlLoader3.load('./src/modelos/arma.mtl', (materials) => {
    materials.preload();

    const objLoader = new OBJLoader();
    objLoader.setMaterials(materials);

    objLoader.load('./src/modelos/arma.obj',
        (object) => {
            console.log('Modelo cargado:', object);
            arma = object;
            arma.position.set(-35, 0, 5);
            arma.scale.set(2, 2, 2);
            scene.add(arma);
        },
        undefined,
        (error) => {
            console.error('Error al cargar el modelo:', error);
        }
    );
});

//Espada
let espada;

const mtlLoader4 = new MTLLoader();
mtlLoader4.load('./src/modelos/espada.mtl', (materials) => {
    materials.preload();

    const objLoader = new OBJLoader();
    objLoader.setMaterials(materials);

    objLoader.load('./src/modelos/espada.obj',
        (object) => {
            console.log('Modelo cargado:', object);
            espada = object;
            espada.position.set(-25, 0, -15);
            espada.scale.set(2, 2, 2);
            scene.add(espada);
        },
        undefined,
        (error) => {
            console.error('Error al cargar el modelo:', error);
        }
    );
});

//Anillo
let anillo;

const mtlLoader5 = new MTLLoader();
mtlLoader5.load('./src/modelos/anillo.mtl', (materials) => {
    materials.preload();

    const objLoader = new OBJLoader();
    objLoader.setMaterials(materials);

    objLoader.load('./src/modelos/anillo.obj',
        (object) => {
            console.log('Modelo cargado:', object);
            anillo = object;
            anillo.position.set(-10, 3, 20);
            anillo.rotateY(4.5);
            anillo.scale.set(3, 3, 3);
            scene.add(anillo);
        },
        undefined,
        (error) => {
            console.error('Error al cargar el modelo:', error);
        }
    );
});

//Nave
let nave;

const mtlLoader6 = new MTLLoader();
mtlLoader6.load('./src/modelos/nave.mtl', (materials) => {
    materials.preload();

    const objLoader = new OBJLoader();
    objLoader.setMaterials(materials);

    objLoader.load('./src/modelos/nave.obj',
        (object) => {
            console.log('Modelo cargado:', object);
            nave = object;
            nave.position.set(-10, 3, 40);
            nave.rotateY(5.5);
            nave.scale.set(3, 3, 3);
            scene.add(nave);
        },
        undefined,
        (error) => {
            console.error('Error al cargar el modelo:', error);
        }
    );
});

// Control de teclas
const keysPressed = {
    w: false,
    a: false,
    s: false,
    d: false,
    space: false
};

window.addEventListener('keydown', (event) => {
    const key = event.key.toLowerCase();
    if (key === ' ') {
        keysPressed.space = true;
    } else if (keysPressed.hasOwnProperty(key)) {
        keysPressed[key] = true;
    }
});

window.addEventListener('keyup', (event) => {
    const key = event.key.toLowerCase();
    if (key === ' ') {
        keysPressed.space = false;
    } else if (keysPressed.hasOwnProperty(key)) {
        keysPressed[key] = false;
    }
});

// Variables para salto
let isJumping = false;
let velocityY = 0;
const gravity = -0.02;
const jumpSpeed = 0.3;
const groundY = 0;

const speed = 0.2;

// Flag para evitar múltiples redirecciones
let collided = false;

renderer.setAnimationLoop(() => {
    if (personaje) {
        // Movimiento horizontal
        if (keysPressed.w) personaje.position.z -= speed;
        if (keysPressed.s) personaje.position.z += speed;
        if (keysPressed.a) personaje.position.x -= speed;
        if (keysPressed.d) personaje.position.x += speed;

        // Saltar
        if (keysPressed.space && !isJumping) {
            isJumping = true;
            velocityY = jumpSpeed;
        }

        if (isJumping) {
            velocityY += gravity;
            personaje.position.y += velocityY;

            if (personaje.position.y <= groundY) {
                personaje.position.y = groundY;
                isJumping = false;
                velocityY = 0;
            }
        }

        // Detectar colisiones y redirigir según objeto
        if (!collided) {
            const personajeBox = new THREE.Box3().setFromObject(personaje);

            if (carro) {
                const carroBox = new THREE.Box3().setFromObject(carro);
                if (personajeBox.intersectsBox(carroBox)) {
                    collided = true;
                    window.location.href = './projects.html';
                    return; // para evitar procesar más redirecciones
                }
            }

            if (espada) {
                const espadaBox = new THREE.Box3().setFromObject(espada);
                if (personajeBox.intersectsBox(espadaBox)) {
                    collided = true;
                    window.location.href = './skills.html';
                    return;
                }
            }

            if (nave) {
                const naveBox = new THREE.Box3().setFromObject(nave);
                if (personajeBox.intersectsBox(naveBox)) {
                    collided = true;
                    window.location.href = './profile.html';
                    return;
                }
            }

            if (arma) {
                const armaBox = new THREE.Box3().setFromObject(arma);
                if (personajeBox.intersectsBox(armaBox)) {
                    collided = true;
                    window.location.href = './merits.html';
                    return;
                }
            }

            if (anillo) {
                const anilloBox = new THREE.Box3().setFromObject(anillo);
                if (personajeBox.intersectsBox(anilloBox)) {
                    collided = true;
                    window.location.href = './education.html';
                    return;
                }
            }
        }
    }

    renderer.render(scene, camera);
});


window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();

    renderer.setSize(window.innerWidth, window.innerHeight);
});