//Boton Volver
document.getElementById('volver').addEventListener('click', function() {
    window.location.href = './index.html';
});